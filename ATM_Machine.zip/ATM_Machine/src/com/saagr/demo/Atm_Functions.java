package com.saagr.demo;

public interface Atm_Functions {
	
	public void viewBalance();
	public void  withdrwal(double withdrwal);
	public void  deposite(double deposite);
	public void  viewMiniStatement();

}

