package com.saagr.demo;

public class Atm_Interface {
	
	private double balance;
	private double deposite;
	private double withdrwal;
	
	  
	
    public Atm_Interface()
    {
    	
    }
    
 
	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public double getDeposite() {
		return deposite;
	}

	public void setDeposite(double deposite) {
		this.deposite = deposite;
	}

	public double getWithdrwal() {
		return withdrwal;
	}

	public void setWithdrwal(double withdrwal) {
		this.withdrwal = withdrwal;
	}

	

}